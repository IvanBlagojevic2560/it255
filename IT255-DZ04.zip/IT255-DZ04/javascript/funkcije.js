/**
 * Created by Ivan on 25.3.2016..
 */
function ispisImena() {
    document.write("Ivan Blagojevic ");
}
function cena(p1,p2) {
   return p1*p2;
   
    
}
function ispisiTekst(tekst) {
    document.write(tekst);
}
function idTest() {
    document.getElementById("1").style.color = "red";
    document.getElementById("1").style.fontSize = "larger";


}
